const Table = (props) => {

    let tabledata = props.mydata;

    //if(tabledata.length ===0) return <p>No Data!</p>;

  return (
    <div>
      {tabledata. length > 0 && <table className="table table-striped">
        <thead>
          <tr>
            <th scope="col">Year</th>
            <th scope="col">Total</th>
            <th scope="col">Gas Fuel</th>
            <th scope="col">Solid Fuel</th>
            <th scope="col">Cement</th>
            <th scope="col">Gas Flaring</th>
          </tr>
        </thead>
        <tbody>
            {tabledata.map((co2)=>(
          <tr>
            <td>{co2.Year}</td>
            <td>{co2["Total"]}</td>
            <td>{co2["Gas Fuel"]}</td>
            <td>{co2["Solid Fuel"]}</td>
            <td>{co2.Cement}</td>
            <td>{co2["Gas Flaring"]}</td>
          </tr>
            ))}
        </tbody>
      </table>}
    </div>
  );
};
export default Table;
