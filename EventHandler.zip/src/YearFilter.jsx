import { useState } from "react";
import { Row, Col, Button, Form } from "react-bootstrap";

const YearFilter = (props) => {
  const [YearFrom, setYearFrom] = useState(1900);
  const [YearTo, setYearTo] = useState(2020);
  const [Order, setOrder] = useState("ASC");

  const handleOrder = (e) => {
    setOrder(e.target.value);
  };
  return (
    <>
      <Row>
        <Col sm={5}>
          <div className="d-flex justify-content-start">
            <Form.Label>Year From</Form.Label>
            <input
              type="text"
              placeholder="Year from..."
              style={{ marginRight: "20px" }}
              onChange={(e) => setYearFrom(e.target.value)}
              value={YearFrom}
            ></input>
            <Form.Range style={{width:"200px"}}
              min={1900}
              max={2020}
              value={YearFrom}
              onChange={(e) => setYearFrom(e.target.value)}
            />
          </div>
        </Col>
        <Col sm={4}>
          <div className="d-flex justify-content-end">
            <Form.Label>Year To</Form.Label>
            <input
              type="text"
              placeholder="Year to..."
              onChange={(e) => setYearTo(e.target.value)}
              value={YearTo}
            ></input>
            <Form.Range style={{width:"200px"}}
              min={1900}
              max={2020}
              value={YearTo}
              onChange={(e) => setYearTo(e.target.value)}
            />
          </div>
        </Col>
        <Col sm={2}>
          <div>
            <input
              type="radio"
              value="ASC"
              name="rdo"
              style={{ marginLeft: "20px" }}
              onChange={handleOrder}
              checked={Order === "ASC"}
            ></input>
            ASC
            <input
              type="radio"
              value="DESC"
              name="rdo"
              style={{ marginLeft: "20px" }}
              onChange={handleOrder}
              checked={Order === "DESC"}
            ></input>
            DESC
          </div>
        </Col>
        <Col sm={1}>
          <Button
            variant="primary"
            onClick={() => props.onYearFilter(YearFrom, YearTo, Order)}
          >
            Filter
          </Button>
        </Col>
      </Row>
    </>
  );
};
export default YearFilter;
