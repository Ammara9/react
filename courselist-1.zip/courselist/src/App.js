//import { BookItem } from './bookitem'

import  {CourseList}  from './courselist'

function App() {
  return (
    <div className="App">      
      {/*<BookItem></BookItem>*/}
      <CourseList/>

    </div>
  );
}

export default App;
