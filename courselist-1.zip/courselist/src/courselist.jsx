import React from 'react'
import { Col, Row, Button } from 'react-bootstrap'

export const CourseList = () => {

    const courseArray = [
        {
            image: "https://www.freeiconspng.com/thumbs/courses-icon/courses-icon-8.png",
            name: "Gränssnittsutveckling",
            code: "C3KGU1",
            year: 2019,
            credit: 7.5,
            desc: "Denna kurs behandlar design och implementation av interaktiva gränssnitt, vilket utgör en central aspekt av front endutveckling. Kursens teoretiska innehåll konkretiseras med tillämpningar i ett webbapplikationsramverk. I kursen behandlas gränssnittsutveckling, interaktionsdesign och användarupplevelse."
        },
        {
            image: "https://www.freeiconspng.com/thumbs/courses-icon/courses-icon-8.png",
            name: "UX-design: användarupplevelsedesign och utvärdering",
            code: "C3KUX1",
            year: 2019,
            credit: 15,
            desc: "Kursen behandlar teorier och metoder som används inom design för användarupplevelser (user experience). Därtill kommer studenterna genom praktiska arbetssätt att fördjupa sin förståelse för de grundläggande begrepp, praktiker, arbetsflöden, processer, tekniker och verktyg som är förknippade med UX-design och UX-evaluering inom webbutveckling. Kursen utgår från ett användarcentrerat perspektiv och tar framför allt avstamp i områdena informationsarkitektur, interaktionsdesign och UX."
        },
        {
            image: "https://www.freeiconspng.com/thumbs/courses-icon/courses-icon-8.png",
            name: "Modelling",
            code: "C3KMD1",
            year: 2019,
            credit: 7.5,
            desc: "Kursen behandlar metoder för att skapa modeller av specifika situationer, scenarier och system som stöd i processen att planera, designa och implementera webbapplikationer. Modeller över system och scenarier ska realiseras med hjälp av ett visuellt modelleringsspråk kallat Unified Modelling Language (UML). I kursen kommer objektorienterad utveckling samt systemutvecklingsprocess för analys och design av IT-system att presenteras"
        },
        {
            image: "https://www.freeiconspng.com/thumbs/courses-icon/courses-icon-8.png",
            name: "Tillämpad teori och metod",
            code: "C3KTI1",
            year: 2020,
            credit: 15,
            desc: "Kursen syftar till att studenten ska utveckla en metodologisk och epistemologisk förståelse för vetenskaplig verksamhet och vara väl förberedd för uppsatsarbete genom att presentera, studera och värdera vanligen förekommande forskningsmetoder och forskningsansatser med relevans för problem inom informationsarkitektur."
        },
        {
            image: "https://www.freeiconspng.com/thumbs/courses-icon/courses-icon-8.png",
            name: "Information genom bild och text",
            code: "C3KIB1",
            year: 2018,
            credit: 15,
            desc: "Kursen introducerar teorier och tillämpningar inom området informationsdesign. Studenten får träna sig i att skapa informationsgrafik där bild och text utformas till en samstämmig enhet, och reflektera över hur samspelet kan resultera i en tydlig informationsdesign för användaren. Utifrån ett teoretiskt perspektiv får studenten också analysera multimodalitet och diskutera formgivningens betydelse för, och effekt på, individ och samhälle, samt reflektera över designetiska aspekter på information."
        },
    ]


    return (
/*        
        courseArray.map(course => (
            <Row className="m-5 border p-2">
                <Col sm="auto" className="p-1" >
                    <img src={course.image} style={{ width: "200px" }} />
                </Col>
                <Col className="d-flex flex-column">
                    <div className="h4 mb-1">{course.name}</div>
                    <div className="font-weight-bold text-secondary mb-1">{course.code}</div>
                    <div className="font-weight-bold text-info mb-1">{course.year}</div>
                    <div className="mb-2" style={{ flex: "1 0 100px", overflow: 'hidden' }}>{course.desc}</div>
                    <div>
                        <Button size="md" variant="danger">{course.credit} hp</Button>
                    </div>

                </Col>
            </Row>
        ))
*/
  
/*here is the table format*/


        <table className="table table-striped">
            <thead>
                <tr>
                    <th scope="col">Name</th>
                    <th scope="col">Code</th>
                    <th scope="col">Year</th>
                    <th scope="col">Credit</th>
                    <th scope="col">Description</th>
                </tr>
            </thead>
            <tbody>
                {courseArray.filter(x=> x.credit >10).map(course => (
                    <tr style={{ fontSize: "1.1rem" }}>
                        <td>{course.name}</td>
                        <td>{course.code}</td>
                        <td>{course.year}</td>
                        <td>{course.credit}</td>
                        <td>{course.desc}</td>
                    </tr>
                ))}
            </tbody>
        </table>

    )
}
