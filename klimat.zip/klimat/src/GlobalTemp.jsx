import React from "react";


/*This component shows detail of .*/
export const GlobalTemp = () => {
  return (
   
    <div className="d-flex justify-content-center align-items-center vh-100">
      global temp
    </div>
  );
};
