import React, { useEffect, useState } from "react";
import { Container, Row, Col } from "react-bootstrap";

import Question from "./Question";
import QuizResult from "./QuizResult";
import shuffleArray from './utils';

const Quiz = () => {
  const [QuizData, setQuizData] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [modalShow, setModalShow] = React.useState(false);

  useEffect(() => {
    const url = "/data/quizdata.json";
    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        data.map(
          p => p.all_answers = [p.correct_answer, ...p.incorrect_answers]);
          shuffleArray(data);
          data.map(p=>shuffleArray(p.all_answers));
        setQuizData(data);
      });
  }, []);

  const handlePrev = ()=>{
    if(currentIndex > 0)
    setCurrentIndex(currentIndex-1);        
  }
  const handleNext = ()=>{
    if(currentIndex < QuizData.length-1)
    setCurrentIndex(currentIndex+1);        
  }

  const onAnswer =(ans) =>{

    QuizData[currentIndex].isCorrect = QuizData[currentIndex].correct_answer === ans;
    QuizData[currentIndex].currentUserAnswer = ans;
    setQuizData([...QuizData])

  }

  const handleFinish=()=>{
    setModalShow(true);
  }

  const handleReset = ()=>{
    setCurrentIndex(0);
    QuizData.map(p=>p.currentUserAnswer="");
    shuffleArray(QuizData);
    QuizData.map(p=>shuffleArray(p.all_answers));
    setQuizData([...QuizData]);
  }
 

  return (
    <div className="mx-auto">
      
      <Container className="card mt-5">
      <Row>
          <Col sm={2}></Col>
          <Col sm={8}>
            <Question data={QuizData[currentIndex]} index={currentIndex} numberOfQuestion={QuizData.length} onAnswer={onAnswer}></Question>
            <div className="mt-2 ">
              <div className="text-center">
                <a href="#" class="btn m-2" style={{ backgroundColor: "#4CAF83" }} onClick={handlePrev} >Förgående</a>
                <a href="#" class="btn btn-primary" onClick={handleNext}>Nästa</a>
                <a href="#" class="btn m-2" style={{ backgroundColor: "#4CAF83" }} onClick={handlePrev} >Stäng</a>
              </div>
              <div>
               {(currentIndex == QuizData.length-1) && <a href="#" class="btn btn-secondary m-2" onClick={handleFinish}>Finish</a>}
              </div>
            </div>
          </Col>
          <Col sm={2}></Col>
        </Row>
      </Container>

      <QuizResult
              show={modalShow}
              onHide={() => {setModalShow(false);handleReset();}}
              numberOfQuestion={QuizData.length} numberOfCorrectAnswers={QuizData.filter(p=>p.isCorrect).length}
      ></QuizResult>




    </div>

  );
};

export default Quiz;
