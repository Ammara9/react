const Question = (props) => {
  const data = props.data;

  if (data === undefined) return <p>There is no data</p>;

  const handleChange= (e)=>{
      props.onAnswer(e.target.value)
      //notify the parent 
  }
  const currentQuestion = data;
  const currentUserAnswer = data.currentUserAnswer;
  return (

    <div >

      <div class="card-header text-center">
      <div class="text-muted">Question {props.index + 1} / {props.numberOfQuestion}</div>
      <h5 class="card-title text-danger">{(props.index + 1)+ ". "+ currentQuestion.question}</h5>
      </div>


      <div class="card-body">
       

        {currentQuestion.all_answers.map((answer) => (
          <div className="mx-auto form-check card-body border rounded w-50 text-center" style={{backgroundColor: "#C2EDCE", alignContent: "center"}}>
          <input
            class="form-check-input"
            type="radio"
            name="flexRadioDefault"
            id="flexRadioDefault1"
            value={answer}
            checked={currentUserAnswer=== answer ? true:false}
            onChange={handleChange}
          />
          <label class="form-check-label" for="flexRadioDefault1">
            {answer}
          </label>
        </div>
        ))}
      </div>

      

    </div>
  );
};

export default Question;
