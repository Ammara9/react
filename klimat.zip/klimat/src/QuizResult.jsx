import { Modal, Button } from "react-bootstrap";
import { Rating } from "semantic-ui-react";
import { Link } from "react-router-dom";


function QuizResult(props) {
  return (
    <Modal 
      {...props}
      size="xl"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Link as={Link} to="/quizstart" style={{ backgroundColor: "#4CAF83" }}>   
      <Modal.Header closeButton> 
      </Modal.Header >
      </Link>

      <Modal.Body style={{ backgroundColor: "#4CAF83" }}>
      <Modal.Title id="contained-modal-title-vcenter">
          *** Quiz Resultat ***
        </Modal.Title>

          <div className="d-flex justify-content-between" >
        <h4>
          Du Svarade {props.numberOfCorrectAnswers} frågor av {" "}
          {props.numberOfQuestion} rätt.
        </h4>
        <Rating
          icon="star"
          defaultRating={
            props.numberOfCorrectAnswers > 8
              ? 5
              : props.numberOfCorrectAnswers > 6
              ? 4
              : 3
          }
          maxRating={5}
        />
        </div>
        <p>
          You can click on close button and redo the Quiz. However, the order of
          the questions and answers will be different.
        </p>
      </Modal.Body>
      <Modal.Footer style={{ backgroundColor: "#4CAF83" }}>
        Tack för denna gång
      </Modal.Footer>
    </Modal>
  );
}

export default QuizResult;
