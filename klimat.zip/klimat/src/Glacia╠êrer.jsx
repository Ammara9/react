import React from "react";
import { Card, Container } from "react-bootstrap";
import DatasetGlacierSize from './DatasetGlacierSize';

/*This component shows detail of company*/
export const Glaciärer = () => {
  return (
    <div className="">
     < DatasetGlacierSize />

    </div>
  );
};
