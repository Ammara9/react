import React from "react";
import { Button } from "react-bootstrap";
import { Link } from "react-router-dom";

export const Home = () => {
  //here we used state to save the search phrase by the user

  return (
    <div>
      <Link as={Link} to="/Glaciärer">
        <Button className="button" style={{ backgroundColor: "#3E5682" }}>
          Glaciärer
        </Button>
      </Link>

      <Link as={Link} to="/Havsnivå">
        <Button className="button" style={{ backgroundColor: "#3E5682" }}>
          Havsnivå
        </Button>
      </Link>

      <Link as={Link} to="/GlobalTemp">
        <Button className="button" style={{ backgroundColor: "#3E5682" }}>
          Global Temperatur
        </Button>
      </Link>
    </div>
  );
};
