import React from "react";
import { Navbar, Nav } from "react-bootstrap";
import mylogo from "./img/logga.png";
import { Link } from "react-router-dom";

export const NavBar = () => {
  //here we used state to save the search phrase by the user

  return (
    <div>
      <Navbar
        className="d-flex fixed-top text-white"
        style={{ backgroundColor: "#4caf83" }}
      >
        {/*here is the title on the header*/}
        <div>
          <Link
            as={Link}
            to="/home"
            className=" hover-overlay d-flex justify-content-between"
            style={{ textDecoration: "none" }}
          >
            <img className="mx-2" src={mylogo} style={{ height: "70px", width: "250px" }}></img>
            
          </Link>
        </div>

        <div className="justify-content-center">
          <Nav>
            {/*We need Link for React router. however here we have "NavLink". To convert it to Link component we have user "as" keyword here. */}
            {/*here is the links the left side of the header*/}
            <Nav.Link as={Link} to="/home" className="text-white">
              Hem
            </Nav.Link>

            <Nav.Link as={Link} to="/Glaciärer" className="text-white">
              Glaciärer
            </Nav.Link>

            <Nav.Link as={Link} to="/Havsnivå" className="text-white">
              Havsnivå
            </Nav.Link>

            <Nav.Link as={Link} to="/GlobalTemp" className="text-white">
              Global Temperatur
            </Nav.Link>

            <Nav.Link as={Link} to="/quizstart" className="text-white">
              Quiz
            </Nav.Link>
          </Nav>
        </div>
      </Navbar>
    </div>
  );
};
