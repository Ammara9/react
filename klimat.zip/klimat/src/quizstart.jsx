import React from "react";
import { Link } from "react-router-dom";
import { Button } from "react-bootstrap";

/*This component shows detail of .*/
export const quizstart = () => {
  return (
    <div className="" style={{ backgroundColor: "#C2EDCE" }}>
      <div
        className="mt-5 pb-5 container border rounded text-center"
        style={{ backgroundColor: "#F6F6F2" }}
      >
        <div class="row">
          <div class="col-md-6 offset-md-3 mt-5">
            <div class="align-items-center">
              <h1 class="">Quiz</h1>
              <h2 className="text-danger">
                Börja Quizzet för att utveckla kunskap.
              </h2>
              <Link as={Link} to="/quiz">
              <Button className="" style={{ backgroundColor: "#4CAF83" }}>
                Start Quiz
              </Button>
              </Link>
              <div></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
