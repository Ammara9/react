import React from "react";
import { Link } from "react-router-dom";
import { Button } from "react-bootstrap";


/*This component shows detail of company*/
export const Havsnivå = () => {
  return (
    <div className="">
    havsnivå
  </div>
  );
};
