import Card from 'react-bootstrap/Card';
import CardGroup from 'react-bootstrap/CardGroup';
import { Container, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';

export const Home = () => {
  //here we used state to save the search phrase by the user

  return (
    <div>
    <CardGroup className='mt-4 mx-5'>
      <Card className='m-2 p-2' style={{ backgroundColor: '#4CAF83', textAlign: 'center', color: 'white', borderRadius: '10px', fontSize: 14, border: 'none', height: '500px'}}>
        <Card.Img variant="top" src="/image/Globalbild.png" height="200" width="50" className="mt-5 rounded-circle"/>
        <Card.Body>
          <Card.Title>Global temperatur</Card.Title>
          <Card.Text>
          Orsaker och effekter av klimatförändringar
          </Card.Text>
        </Card.Body>
        
        {/* link used to route to quiz page with a button*/} 
        <Link as={Link} to="/GlobalTemp">
              <a className="mb-5 btn rounded-pill" style={{ 
                backgroundColor: "#F6F6F2",
                minWidth: '150px',
                fontSize: 'bold',
                 }}>
                 Utforska
              </a>
              </Link>
      </Card>
      <Card className='m-2 p-2' style={{ backgroundColor: '#4CAF83', textAlign: 'center', color: 'white', borderRadius: '10px', fontSize: 14, border: 'none'}}>
        <Card.Img variant="top" src="/image/havnivabild.png" className="mt-5 rounded-circle"
              alt="Waves Background" height="200"  />
        <Card.Body>
          <Card.Title>Havsnivå</Card.Title>
          <Card.Text>
          Påverkan av jordens havsnivå till följd av klimatet{' '}
          </Card.Text>
        </Card.Body>
        {/* link used to route to quiz page with a button*/} 
        <Link as={Link} to="/Havsnivå">
              <a className="mb-5 btn rounded-pill" style={{ 
                backgroundColor: "#F6F6F2",
                minWidth: '150px',
                fontSize: 'bold',
               
                 }}>
                 Utforska
              </a>
              </Link>
      </Card>
      <Card className='m-2 p-2' style={{ backgroundColor: '#4CAF83', textAlign: 'center', color: 'white', borderRadius: '10px', fontSize: 14, border: 'none' }}>
        <Card.Img variant="top" src="/image/sea-leaval.png" height="200" width="50" className="mt-5 rounded-circle"/>
        <Card.Body>
          <Card.Title>Glaciärer</Card.Title>
          <Card.Text>
          Effekten av klimatförändringar på glaciärerna
          </Card.Text>
        </Card.Body>
        {/* link used to route to quiz page with a button*/} 
        <Link as={Link} to="/Glaciärer">
              <a className="mb-5 btn rounded-pill" style={{ 
                backgroundColor: "#F6F6F2",
                minWidth: '150px',
                fontSize: 'bold',
                 }}>
                Utforska
              </a>
              </Link>
      </Card>
    </CardGroup>



    <Container className="my-4 p-2" style={{ backgroundColor: '#F6F6F2', color: 'black',borderRadius: '10px', fontSize: 18, border: 'none'}}>
    <Row>
      {/* Left part with text */}
      <Col md={12} lg={6} >
        <div className='p-2 m-2'>
          <h1 style={{ fontSize: 34, marginBottom: '20px'}}>Lär dig genom quiz</h1>

          
         <p>Du kan testa dina kunskaper i global temperatur, havsnivåer och
                glaciärer genom vårt quiz! </p>
                {/* link used to route to quiz page with a button*/} 
               <Link as={Link} to="/quizstart">
              <a className="mt-5 btn rounded-pill text-white" style={{ 
                backgroundColor: "#4CAF83",
                minWidth: '150px',
                fontSize: 'bold',
                 }}>
                Testa vårt quiz
              </a>
              </Link>
        </div>
      
      </Col>

      {/* Right part with an image */}
      <Col md={12} lg={6}>
        <img
          src="/image/10009641.png" 
          alt="hero"
            style={{width: 400}}
           className="img-fluid m-4"
        />
      </Col>
    </Row>
  </Container>

    </div>
  );
};
