import { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import { ref, set, update, get } from "firebase/database";
import { storageReference } from "../firebase";
import { getAuth } from "firebase/auth";

const QuizResult = (props) => {
 const [showConfetti, setShowConfetti] = useState(false);

 useEffect(() => {
    setShowConfetti(true);
    const timer = setTimeout(() => {
      setShowConfetti(false);
    }, 3000);
    return () => clearTimeout(timer);
 }, []);

 useEffect(() => {
    if (props.auth.currentUser) {
      updateUserData(props.auth.currentUser.uid, props.auth.currentUser.email, props.numberOfCorrectAnswers);
    }
 }, [props.auth, props.numberOfCorrectAnswers]);

 const updateUserData = (uid, email, points) => {
    console.log("Saving points:", points);
    update(ref(db, `users/${uid}`), {
      email,
      points,
    });
 };
 return (
    <Modal
      {...props}
      size="xl"
      centered
    >

      <Modal.Header style={{ backgroundColor: "#4CAF83" }}>
      </Modal.Header>

      <Modal.Body style={{ backgroundColor: "#4CAF83" }}>
        <div className="d-flex justify-content-center align-content-center">
          <h4>
            Du Svarade {props.numberOfCorrectAnswers} frågor av {" "}
            {props.numberOfQuestion} rätt.
          </h4>

<div className="justify-content-center align-content-center">
          <Link as={Link} to="/quizstart">
            <a className="btn mx-auto rounded-pill text-dark justify-content-center align-content-center" style={{ backgroundColor: "white" }}>
              Avsluta Quiz
            </a>
          </Link>
          </div>
        </div>
        {props.numberOfCorrectAnswers > 6 && (
          <Confetti
            className="confetti"
            gravity={0.4}
            run={props.showConfetti}
            numberOfPieces={props.numberOfCorrectAnswers * 10}
          />
        )}
      </Modal.Body>

      <Modal.Footer style={{ backgroundColor: "#4CAF83" }}>
      </Modal.Footer>
    </Modal>
 );
}

export default QuizResult;