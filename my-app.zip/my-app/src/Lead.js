import { Switch, Route, Redirect } from "react-router-dom";

import { NavBar } from "./navbar";
import { Footer } from "./footer";
import { GlobalTemp } from "./GlobalTemp";
import { Glaciärer } from "./Glaciärer";
import { resturants } from "./resturants";
import { Havsnivå } from "./Havsnivå";
import { quizstart } from "./quizstart";
import Quiz from "./quiz";
import { Home } from "./home";

/*This is the root component and starting point to render other components.*/
function Lead() {
  return (
    <div className="d-flex flex-column min-vh-100" style={{ marginTop: "100px", fontFamily: "Times" }}>
      {/*here Navbar renders and no need to place it inside Swith because we want always to render it*/}

      <NavBar />

      {/*here we use a switch to render the component that we need. Switch means that one of the Route renders and others are ignored*/}
      <Switch>
        {/* "/:hotelID" is a method to send the data inside the address bar*/}
        <Route path="/home" component={Home}></Route>

        {/* "/:category/:searchPhrase?" is a method to send two input data inside the address bar. the symbol "?" here means that the value of the searchPhrase can be also null*/}
        <Route path="/resturants" component={resturants}></Route>

        <Route path="/GlobalTemp" component={GlobalTemp} />

        <Route path="/Glaciärer" component={Glaciärer} />
        <Route path="/Havsnivå" component={Havsnivå} />
        <Route path="/quiz" component={Quiz} />
        <Route path="/quizstart" component={quizstart} />
        <Route path="/home" component={Home} />

        {/*we redirect the user to the all hotel component if the user enters an invalid address and none of the Routes match.*/}
        <Redirect to="/home"></Redirect>
      </Switch>

     
     < Footer/>
    </div>
  );
}

export default Lead;
