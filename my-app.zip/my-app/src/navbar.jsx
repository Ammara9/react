import React from "react";
import { Navbar, Nav, NavDropdown } from "react-bootstrap";
import mylogo from "./img/logo.png";
import { Link } from "react-router-dom";

export const NavBar = () => {
 return (
    <div>
      <Navbar
        className="fixed-top text-white"
        style={{ backgroundColor: "#4caf83" }}
        expand="lg"
      >
        <Navbar.Brand style={{ marginLeft: '2rem' }}>
          <Link
            as={Link}
            to="/home"
            className="hover-overlay "
            style={{ textDecoration: "none" }}
          >
            <img className="" src={mylogo} style={{ height: "70px", width: "250px" }}></img>
            
          </Link>
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto" style={{ marginLeft: '15rem', fontSize: '1.5rem' }}>
            <Nav.Link as={Link} to="/Glaciärer" className="text-white">
              Glaciärer
            </Nav.Link>

            <Nav.Link as={Link} to="/Havsnivå" className="text-white">
              Havsnivå
            </Nav.Link>

            <Nav.Link as={Link} to="/GlobalTemp" className="text-white">
              Global Temperatur
            </Nav.Link>

            <Nav.Link as={Link} to="/quizstart" className="text-white">
              Quiz
            </Nav.Link>
          </Nav>

          <Nav style={{ marginLeft: '15rem' }}>
            <NavDropdown
              className="align-items-center"
              title={
               <img
                 src="image/persona.icon.png"
                 className="rounded-circle"
                 height="30"
                 alt="Black and White Portrait of a Man"
                 loading="lazy"
               />
              }
            >
              <NavDropdown.Item href="#" style={{ color: 'white', backgroundColor: '#4CAF83' }}>Min profil</NavDropdown.Item>
              <NavDropdown.Item as={Link} to="/login" style={{ color: 'white', backgroundColor: '#4CAF83' }}>
               Logga ut
              </NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    </div>
 );
};