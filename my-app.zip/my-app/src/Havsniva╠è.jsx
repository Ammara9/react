import React from "react";
import { Link } from "react-router-dom";
import { Button } from "react-bootstrap";
import DatasetSeaeLevel from './DatasetSeaLevel'

/*This component shows detail of company*/
export const Havsnivå = () => {
  return (
    <div className="my-5 mx-5">
    <DatasetSeaeLevel />
  </div>
  );
};
