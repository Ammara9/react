import React, { useState } from "react";

const Question = (props) => {
 const data = props.data;

 if (data === undefined) return <p>There is no data</p>;

 const handleChange = (e) => {
    props.onAnswer(e.target.value);
    //notify the parent 
 };


 const currentQuestion = data;
 const currentUserAnswer = data.currentUserAnswer;

 return (

  <Question
  data={QuizData[currentIndex]}
  index={currentIndex}
  numberOfQuestion={QuizData.length}
  onAnswer={onAnswer}
></Question>

<Container className="mt-2">
  <Row>
    <Col xs={12} style={{ textAlign: "center" }}>
      {currentIndex !== QuizData.length - 10 && (
        <Button className="rounded-pill"
          variant="primary"
          style={{
            float: "left",
            backgroundColor: "#4CAF83",
          }}
          onClick={handlePrev}
        >
          Tillbaka
        </Button>
      )}

      {currentIndex !== QuizData.length - 1 && (
        <Button className="rounded-pill"
          variant="primary"
          style={{
            float: "right",
            backgroundColor: "#4CAF83",
          }}
          onClick={handleNext}
        >
          Nästa
        </Button>
      )}

      {currentIndex == QuizData.length - 1 && (
        <Button className="rounded-pill"
          variant="primary"
          style={{
            float: "right",
            backgroundColor: "#4CAF83",
          }}
          onClick={handleFinish}
        >
          Slutför
        </Button>
      )}
    </Col>
  </Row>
</Container>

 );
};

export default Question;