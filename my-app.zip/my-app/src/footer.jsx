import React from "react";
import mylogo from "./img/logga.png";
import { Link } from "react-router-dom";

//this component contains the footer and we have used bootstrap classes to create the footer.
export const Footer = () => {
  return (
    <div className="mt-auto text-center  text-lg-start text-light border-dark " style={{ backgroundColor: '#4CAF83' }}>

      <section className="">

        <div className="container text-center text-md-start mt-2">
          <div className="row mt-3">
            <div className="col-md-3 col-lg-4 col-xl-4  ">
            <Link
            as={Link}
            to="/home"
            className=" hover-overlay "
          >
            <img className="" src={mylogo} alt="logo" style={{ height: "70px", width: "250px",  }}></img>
            
          </Link>
            </div>


            <div className="col-md-2 col-lg-2 col-xl-2 ">
              <p>
            <Link as={Link} to="/Glaciärer" className="text-white hover-overlay" style={{ textDecoration: "none" }}>
              Glaciärer
            </Link>
            </p>
            <p>
            <Link as={Link} to="/Havsnivå" className="text-white hover-overlay" style={{ textDecoration: "none" }}>
              Havsnivå
            </Link>
            </p>
            <p>
            <Link as={Link} to="/GlobalTemp" className="text-white hover-overlay" style={{ textDecoration: "none" }}>
              Global Temperatur
            </Link>
            </p>
            </div>

            <div className="col-md-3 col-lg-2 col-xl-3">
              <p className="mb-2" >Prenumerera på vårt nyhetsbrev</p>
              <p>
              <input
             className="rounded-pill"
             type="text"
            placeholder="E-post"
             
             
             
          /></p>
            </div>
            <div className="col-md-4 col-lg-3 col-xl-3  mb-md-0">
              <h6 className="text-uppercase fw-bold mb-2">Contact Number</h6>
              <p>
                <i className="fas fa-phone me-3"></i> +46 8-555 555 55
              </p>
            </div>
          </div>
        </div>
       
      </section>

    </div>
  );
};
