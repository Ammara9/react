import React from "react";
import DatasetGlobalTemp from './DatasetGlobalTemp'


/*This component shows detail of .*/
export const GlobalTemp = () => {
  return (
   
    <div className="text-center">
      <h1>hello</h1>

      <div className="my-5 mx-5">
      < DatasetGlobalTemp />
      </div>

    </div>
  );
};
