import { BookItem } from './bookitem'

function App() {
  return (
    <div className="App">
      <BookItem></BookItem>
    </div>
  );
}

export default App;
