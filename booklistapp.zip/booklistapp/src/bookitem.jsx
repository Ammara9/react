import React from 'react'
import { Col, Row, Button } from 'react-bootstrap'

export const BookItem = () => {
    const bookArray = [
        {
            title: "Designing User Experience",
            subTitle: "A Guide to Hci, UX and Interaction Design",
            desc: "Designing User Experience presents a comprehensive introduction to the practical issue of creating interactive systems, services and products from a human-centred perspective. It develops the principles and methods of human-computer interaction (HCI) and Interaction Design (ID) to deal with the design of twenty-first-century computing and the demands for improved user experience (UX). It brings together the key theoretical foundations of human experiences when people interact with and through technologies. It explores UX in a wide variety of environments and contexts.",
            image: "https://images-na.ssl-images-amazon.com/images/I/41B5mynRvDL._SX366_BO1,204,203,200_.jpg",
            author: "David Benyon",
            price: "500"
        },
        {
            title: "Interaction Design",
            subTitle: "Beyond Human-Computer Interaction",
            desc: "Hugely popular with students and professionals alike, the Fifth Edition of Interaction Design is an ideal resource for learning the interdisciplinary skills needed for interaction design, human-computer interaction, information design, web design, and ubiquitous computing. New to the fifth edition: a chapter on data at scale, which covers developments in the emerging fields of 'human data interaction' and data analytics. The chapter demonstrates the many ways organizations manipulate, analyze, and act upon the masses of data being collected with regards to human digital and physical behaviors, the environment, and society at large.",
            image: "https://images-na.ssl-images-amazon.com/images/I/51uPl9ue9LL._SX404_BO1,204,203,200_.jpg",
            author: "Helen Sharp, Jennifer Preece, Yvonne Rogers",
            price: "400"
        },
        {
            title: "Interaktionsdesign och UX",
            subTitle: "Om att skapa en god användarupplevelse",
            desc: "Interaktionsdesign och UX handlar om tekniker för att utforma nyskapande interaktiva produkter och tjänster med god användarupplevelse. God användarupplevelse, eller UX (eng. user experience), är det övergripande målet för designarbetet. Den här boken är tänkt som ett praktiskt stöd under hela designprocessen: från initiala insikter och formulerade avsikter, till konceptidéer och test av prototyper. Tyngdpunkten ligger på de tidiga faserna där designens inriktning fastställs.",
            image: "https://image.bokus.com/images/9789144122991_200x_interaktionsdesign-och-ux-om-att-skapa-en-god-anvandarupplevelse_haftad",
            author: "Mattias Arvola",
            price: "316"
        }
    ]
    return (
        bookArray.map(book => (
            <Row className="m-5 border p-2">
                <Col sm="auto" className="p-1" >
                    <img src={book.image} style={{ width: "200px" }} />
                </Col>
                <Col className="d-flex flex-column">
                    <div className="h4 mb-1">{book.title}</div>
                    <div className="font-weight-bold text-secondary mb-1">{book.subTitle}</div>
                    <div className="font-weight-bold text-info mb-1">{book.author}</div>
                    <div className="mb-2" style={{ flex: "1 0 100px", overflow: 'hidden' }}>{book.desc}</div>
                    <div>
                        <Button size="md" variant="danger">Buy {book.price} SEK</Button>
                    </div>

                </Col>
            </Row>
        ))
    )
}
